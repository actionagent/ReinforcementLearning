
import numpy as np
import matplotlib.pyplot as plt
import random

no_of_bandit=2000 # number of bandit
k=10 # number of arms in each bandit 
no_of_pulls=1000 # number of times to pull each arm

q_true=np.random.normal(0,1,(no_of_bandit,k)) 
true_opt_arms=np.argmax(q_true,1) 

c_list=[1,3,2] # controls degree of exploration
col=['k','g','r']
fig1=plt.figure().add_subplot(111)
fig2=plt.figure().add_subplot(111)
fig3=plt.figure().add_subplot(111)

eps=0.1 # comparing with epsilon-greedy method
flag=0 # flag variable to plot ucb vs eps plot only for c=2 in ucb 

for c in range(len(c_list)) : 

	print ('Index of C:',c, 'Value of C:', c_list[c])
	Q=np.zeros((no_of_bandit,k)) # reward estimated
	N=np.ones((no_of_bandit,k)) #each arm is pulled atleast once
	
	Q_eps=np.zeros((no_of_bandit,k)) #  epsilon-greedy method
	N_eps=np.ones((no_of_bandit,k)) #  
	# Pull all arms once
	Qi=np.random.normal(q_true,1) 
	avg_Qi=np.mean(Qi)
        #reward calculation
	R_c=[]
	R_c.append(0)
	R_c.append(avg_Qi)
	R_c_opt=[] 

	R_eps=[]
	R_eps.append(0)
	R_eps.append(avg_Qi)

	for pull in range(2,no_of_pulls+1) : 
		R_pull=[]
		R_pull_eps=[]
		opt_arm_pull=0

		for i in range(no_of_bandit) : 
		
			ucb_Q=Q[i]+np.sqrt(c_list[c]*np.log(pull)/N[i])
			j=np.argmax(ucb_Q)
			if j==true_opt_arms[i] : 
				opt_arm_pull=opt_arm_pull+1

			temp_R=np.random.normal(q_true[i][j],1)
			R_pull.append(temp_R)
			N[i][j]=N[i][j]+1
			Q[i][j]=Q[i][j]+(temp_R-Q[i][j])/N[i][j]


			if flag==2 : 

				# epsilon-greedy
				if random.random()<eps : 
					j_eps=np.random.randint(k)											
				else : 
					j_eps=np.argmax(Q_eps[i])

				temp_R_eps=np.random.normal(q_true[i][j_eps],1)
				R_pull_eps.append(temp_R_eps)
				N_eps[i][j_eps]=N_eps[i][j_eps]+1
				Q_eps[i][j_eps]=Q_eps[i][j_eps]+(temp_R_eps-Q_eps[i][j_eps])/N_eps[i][j_eps]

				
		avg_R_pull=np.mean(R_pull)
		if flag==2 : 
			avg_R_pull_eps=np.mean(R_pull_eps)
			R_eps.append(avg_R_pull_eps)
			
		R_c.append(avg_R_pull)
		R_c_opt.append(float(opt_arm_pull)*100/2000)
		

	fig1.plot(range(0,no_of_pulls+1),R_c,col[c])	
	fig2.plot(range(2,no_of_pulls+1),R_c_opt,col[c])

	
	if flag==2 : 
		fig3.plot(range(0,no_of_pulls+1),R_eps,'g')
		fig3.plot(range(0,no_of_pulls+1),R_c,'k')
	flag=flag+1

plt.rc('text')

fig1.title.set_text('UCB1 : Average Reward Vs Steps')
fig1.set_ylabel('Average Reward')
fig1.set_xlabel('Steps')
fig1.legend((r"c=1",r"c=3",r"c=2"),loc='best')

fig2.title.set_text(r'UCB1 : $\%$ Optimal Action Vs Steps')
fig2.set_ylabel(r'$\%$ Optimal Action')
fig2.set_xlabel('Steps')
fig2.set_ylim(0,100)
fig2.legend((r"c=1",r"c=3",r"c=2"),loc='best')

fig3.title.set_text(r'UCB1 versus $\epsilon$-greedy : Average Reward')
fig3.set_ylabel('Average Reward')
fig3.set_xlabel('Steps')
fig3.legend((r"$\epsilon$="+str(eps),r"c="+str(c_list[2])),loc='best')
plt.show()
