import numpy as np
import matplotlib.pyplot as plt
import random

no_of_bandits=2000 #  total number of bandit
k=10 # number of arms in each bandit
no_of_pulls=1000 # number of times to pull each arm

q_true=np.random.normal(0,1,(no_of_bandits,k)) # true means q*(a) for each arm for all bandits
true_opt_arms=np.argmax(q_true,1) # the true optimal arms in each bandit
epsilon=[0,0.01,0.1,0.2,1]  #epsilon values for each iteration

col=['y','b','k','g','r'] #color strides for plot for different values of epsilon
fig1=plt.figure().add_subplot(111)
fig2=plt.figure().add_subplot(111)

for eps in range(len(epsilon)) : 

	print ('epsilon index:',eps,'epsilon value:',epsilon[eps])

	Q=np.zeros((no_of_bandits,k)) #set up initial reward estimates
	N=np.ones((no_of_bandits,k)) 
	# Pull all arms once
	Qi=np.random.normal(q_true,1) 
	R_eps=[]
	R_eps.append(0)
	R_eps.append(np.mean(Qi))	
	R_eps_opt=[]

	for pull in range(2,no_of_pulls+1) :  
		R_pull=[] 
		opt_arm_pull=0 # number of pulss of best arm in this time step
		for i in range(no_of_bandits) : 	

			if random.random()<epsilon[eps] : 
				j=np.random.randint(k)											
			else : 
				j=np.argmax(Q[i])

			if j==true_opt_arms[i] : # To calculate % optimal action
				opt_arm_pull=opt_arm_pull+1

			temp_R=np.random.normal(q_true[i][j],1)
			R_pull.append(temp_R)
			N[i][j]=N[i][j]+1
			Q[i][j]=Q[i][j]+(temp_R-Q[i][j])/N[i][j] #epsilon greedy algoithm implementation
		
		avg_R_pull=np.mean(R_pull)		
		R_eps.append(avg_R_pull)
		R_eps_opt.append(float(opt_arm_pull)*100/2000)
	fig1.plot(range(0,no_of_pulls+1),R_eps,col[eps])
	fig2.plot(range(2,no_of_pulls+1),R_eps_opt,col[eps])

plt.rc('text')
fig1.title.set_text(r'$\epsilon$-greedy : Average Reward Vs Number of Steps')
fig1.set_ylabel('Average Reward')
fig1.set_xlabel('Steps')
fig1.legend((r"$\epsilon=$"+str(epsilon[0]),r"$\epsilon=$"+str(epsilon[1]),r"$\epsilon=$"+str(epsilon[2]),r"$\epsilon=$"+str(epsilon[3]),r"$\epsilon=$"+str(epsilon[4])),loc='best')
fig2.title.set_text(r'$\epsilon$-greedy : $\%$ Optimal Action Vs Number of Steps')
fig2.set_ylabel(r'$\%$ Optimal Action')
fig2.set_xlabel('Steps')
fig2.set_ylim(0,100)
fig2.legend((r"$\epsilon=$"+str(epsilon[0]),r"$\epsilon=$"+str(epsilon[1]),r"$\epsilon=$"+str(epsilon[2]),r"$\epsilon=$"+str(epsilon[3]),r"$\epsilon=$"+str(epsilon[4])),loc='best')
plt.show()

